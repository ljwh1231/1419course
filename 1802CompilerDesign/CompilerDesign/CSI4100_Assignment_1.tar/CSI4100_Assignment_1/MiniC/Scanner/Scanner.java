package MiniC.Scanner;

import MiniC.Scanner.SourceFile;
import MiniC.Scanner.Token;

public final class Scanner {

  private SourceFile sourceFile;

  private char currentChar;
  private boolean verbose;
  private StringBuffer currentLexeme;
  private boolean currentlyScanningToken;
  private int currentLineNr;
  private int currentColNr;

  private boolean isDigit(char c) {
    return (c >= '0' && c <= '9');
  }


///////////////////////////////////////////////////////////////////////////////

  public Scanner(SourceFile source) {
    sourceFile = source;
    currentChar = sourceFile.readChar();
    verbose = false;
    currentLineNr = -1;
    currentColNr= -1;
  }

  public void enableDebugging() {
    verbose = true;
  }

  // takeIt appends the current character to the current token, and gets
  // the next character from the source program (or the to-be-implemented
  // "untake" buffer in case of look-ahead characters that got 'pushed back'
  // into the input stream).

	private void takeIt() {
    	if (currentlyScanningToken)
    	{
     		 currentLexeme.append(currentChar);
    	}
    	currentChar = sourceFile.readChar();
  	}

	public boolean isAlpha(char c) {
		if(c >= 'A' && c <= 'Z')
			return true;
		else if(c >= 'a' && c <= 'z')
			return true;
		else
			return false;
	}
		
	private int scanToken() {

    switch (currentChar) {

	case '0':  case '1':  case '2':  case '3':  case '4':
	case '5':  case '6':  case '7':  case '8':  case '9':
		StringBuffer tempLexeme;
		tempLexeme.append(currentChar);
      	takeIt();
      	while (isDigit(currentChar)) {
			tempLexeme.append(currentChar);
        	takeIt();
      	}
		if (currentChar=='.') {
			tempLexeme.append(currentChar);
			takeIt();
			if(!isDigit(currentChar)) {
				return Token.FLOATLITERAL;
			}
			while (isDigit(currentChar)) {
				tempLexeme.append(currentChar);
				takeIt();
			}
			if(currentChar!='e' && currentChar !='E') {
				return Token.FLOATLITERAL;
			}
		}
		if (currentChar=='e' || currentChar=='E') {
			tempLexeme.append(currentChar);
			takeIt();
			if(currentChar=='+' || currentChar =='-') {
				tempLexeme.append(currentChar);
				takeIt();
			}
			if(isDigit(currentChar)) {
				while(isDigit(currentChar)) {
					tempLexeme.append(currentChar);
					takeIt();
				}
				return Token.FLOATLITERAL;
			}
			else {
						
			}
		}	
			

	 
      // Note: code for floating point literals is missing here...
      return Token.INTLITERAL;

    case '\u0000': // sourceFile.eot:
      currentLexeme.append('$');
      return Token.EOF;
    // Add code here for the remaining MiniC tokens...

    case '+':
        takeIt();
        return Token.PLUS;
    case '-':
		takeIt();
		return Token.MINUS;
    case '*':
		takeIt();
		return Token.TIMES;
    case '=':
		takeIt();
		if(currentChar=='=') {
	    	takeIt();
	    	return Token.EQ;
		}
		return Token.ASSIGN;
	case '|':
		takeIt();
		if(currentChar=='|') {
			takeIt();
			return Token.OR;
		}
		return Token.ERROR;
	case '&':
		takeIt();
		if(currentChar=='&') {
			takeIt();
			return Token.AND;
		}
		return Token.ERROR;
	case '!':
		takeIt();
		if(currentChar=='=') {
			takeIt();
			return Token.NOTEQ;
		}
		return Token.NOT;
	case '<':
		takeIt();
		if(currentChar=='=') {
			takeIt();
			return Token.LESSEQ;
		}
		return Token.LESS;
	case '>':
		takeIt();
		if(currentChar=='=') {
			takeIt();
			return Token.GREATEREQ;
		}
		return Token.GREATER;
	
    case '/':
		takeIt();
		if(currentChar=='/') {
			while(1) {
				if(currentChar=='\n') {
					takeIt();
					currentLexeme.setLength(0);
					return;
				}
				takeIt();
			}
		}
		else if(currentChar=='*') {
			while(1) {
				takeIt();
				if(currentChar=='*') {
					takeIt();
					if(currentChar=='/') {
						takeIt();
						currentLexeme.setLength(0);
						return;
					}
				}
				if(currentChar=='\u0000') {
					System.out.println("ERROR: unterminated multi-line comment");
					currentLexeme.setLength(0);
					currentLexeme.append('$');
					return Token.EOF;
				}
			}
		}
		else{
			takeIt();					
			return Token.DIV;
		}
	case '"':
		takeIt();
		while(1) {
			takeIt();
			if(currentChar=='\u0000') {
				System.out.println("ERROR: unterminated string literal");
				currentLexeme.setLength(0);
				currentLexeme.append('$');
				return Token.EOF;
			}
			else if(currentChar=='\n') {
				System.out.println("ERROR: unterminated string literal");
				return;
			}
			else if(currentChar=='"') {
				takeIt();
				return Token.STRINGLITERAL;
			}
		}
	
	case 'A':	case 'B':	case 'C':	case 'D':	case 'E':	case 'F':	case 'G':
	case 'H':	case 'I':	case 'J':	case 'K':	case 'L':	case 'M':	case 'N':
	case 'O':	case 'P':	case 'Q':	case 'R':	case 'S':	case 'T':	case 'U':
	case 'V':	case 'W':	case 'X':	case 'Y':	case 'Z':
	case 'a':	case 'b':	case 'c':	case 'd':	case 'e':	case 'f':	case 'g':
	case 'h':	case 'i':	case 'j':	case 'k':	case 'l':	case 'm':	case 'n':
	case 'o':	case 'p':	case 'q':	case 'r':	case 's':	case 't':	case 'u':
	case 'v':	case 'w':	case 'x':	case 'y':	case 'z':
	case '_':
		while(currentChar=='_' || isAlpha(currentChar) || isDigit(currentChar))
			takeIt();
		if (currentLexeme == "bool")
			return Token.BOOL;
		else if (currentLexeme == "else")
			return Token.ELSE;
		else if (currentLexeme == "for")
			return Token.FOR;
		else if (currentLexeme == "float")
			return Token.FLOAT;
		else if (currentLexeme == "if")
			return Token.IF;
		else if (currentLexeme == "int")
			return Token.INT;
		else if (currentLexeme == "return")
			return Token.RETURN;
		else if (currentLexeme == "void")
			return Token.VOID;
		else if (currentLexeme == "while)
			return Token.WHILE;
		else if (currentLexeme == "true" || currentLexeme == "false")
			return Token.BOOLLITERAL;
		return Token.ID;
	


    default:
      takeIt();
      return Token.ERROR;
    }
  }

  public Token scan () {
    Token currentToken;
    SourcePos pos;
    int kind;

    currentlyScanningToken = false;
    while (currentChar == ' '
           || currentChar == '\f'
           || currentChar == '\n'
           || currentChar == '\r'
           || currentChar == '\t')
    {
      takeIt();
    } 

    currentlyScanningToken = true;
    currentLexeme = new StringBuffer("");
    pos = new SourcePos();
    // Note: currentLineNr and currentColNr are not maintained yet!
    pos.StartLine = currentLineNr;
    pos.EndLine = currentLineNr;
    pos.StartCol = currentColNr;
    kind = scanToken();
    currentToken = new Token(kind, currentLexeme.toString(), pos);
    pos.EndCol = currentColNr;
    if (verbose)
      currentToken.print();
    return currentToken;
  }

}
